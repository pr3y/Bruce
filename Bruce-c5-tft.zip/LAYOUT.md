```
.
├── boards
│   ├── [board]
│   │   └── interface.cpp
│   ├── pinouts
│   │   ├── pins_arduino.h
│   │   └── [board].h
│   ├── [board].json
│   └── [board].ini
├── html
├── media
├── lib
│   ├── utility
│   └─ ...
├── include
│   └─ ...
├── src
│   ├── core
│   ├── modules
│   └── main.cpp
├── test
└── platformio.ini
```