## Instructions

* Download the .zip file
* Unzip it into somewhere
* Copy the folder into LittleFS (WebUI) or into your SD Card
* Config > UI Theme > (Find the .json file)
