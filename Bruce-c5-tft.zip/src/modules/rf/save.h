#ifndef RF_SAVE_H
#define RF_SAVE_H
#include "structs.h"

bool rf_raw_save(RawRecording recorded);
#endif
