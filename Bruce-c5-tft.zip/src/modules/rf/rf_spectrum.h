#ifndef __RF_SPECTRUM_H__
#define __RF_SPECTRUM_H__

void rf_spectrum();
void rf_SquareWave();

#endif
