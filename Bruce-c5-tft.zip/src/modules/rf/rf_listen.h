#ifndef RF_LISTEN_H
#define RF_LISTEN_H

#include "rf_utils.h"

void rf_listen();

#endif
