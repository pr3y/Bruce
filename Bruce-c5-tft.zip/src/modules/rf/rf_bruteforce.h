#pragma once

void rf_bruteforce();
