void clicker_setup();
void usbClickerSetup();
void bleClickerSetup();
