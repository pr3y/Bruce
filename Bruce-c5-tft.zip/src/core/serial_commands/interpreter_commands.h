#ifndef __SERIAL_JS_CMD_H__
#define __SERIAL_JS_CMD_H__

#include <SimpleCLI.h>

void createInterpreterCommands(SimpleCLI *cli);

#endif
