#ifndef __SERIAL_SETTINGS_CMD_H__
#define __SERIAL_SETTINGS_CMD_H__

#include <SimpleCLI.h>

void createSettingsCommands(SimpleCLI *cli);

#endif
