#ifndef __SERIAL_WIFI_CMD_H__
#define __SERIAL_WIFI_CMD_H__

#include <SimpleCLI.h>

void createWifiCommands(SimpleCLI *cli);

#endif
