#include <globals.h>

void find_i2c_addresses();
uint8_t find_first_i2c_address();
bool check_i2c_address(uint8_t i2c_address);
